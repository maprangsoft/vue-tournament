export default interface IFeedIn {
    id: string | number;
    name?: string;
}