export default interface ITeam {
    id: string | number;
    name?: string;
    score?: number;
}