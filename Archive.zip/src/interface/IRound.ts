import IMatch from "./IMatch";

export default interface IRound {
    matchs: IMatch[];
}